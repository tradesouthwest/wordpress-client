The full documentation can be found in the 'documentation' folder located inside the download package.

CSS added to customizer by Larry @codeable

#Top_bar a.action_button.yith-items-button{
	font-size:small;
	height:3.333em;
	padding: 8px 7px 8px;
  background: transparent;
  color: #e65300;
  border: 2px solid #e65300;}
#Top_bar .top_bar_right{
	padding:0;} 
#yithQuoteItem{
	display:flex;}
#quoteItemQnty{position:relative;top:-1.55em;left:2px}
